var annotated_dup =
[
    [ "DCEL", "class_d_c_e_l.html", "class_d_c_e_l" ],
    [ "Face", "class_face.html", "class_face" ],
    [ "HalfEdge", "class_half_edge.html", "class_half_edge" ],
    [ "Vertex", "class_vertex.html", "class_vertex" ]
];