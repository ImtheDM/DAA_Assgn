var class_face =
[
    [ "incidentEdge", "class_face.html#a6e5f93a441df5d11260fcad7b0ba13bf", null ]
];