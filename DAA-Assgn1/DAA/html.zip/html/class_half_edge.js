var class_half_edge =
[
    [ "HalfEdge", "class_half_edge.html#adf7f4bd68f46211cf8323f0585ed6242", null ],
    [ "HalfEdge", "class_half_edge.html#a964874103e39fa4bd10b95493d0c35ad", null ],
    [ "next", "class_half_edge.html#a5918db069bb8b4a89e471c01a14fc6e1", null ],
    [ "origin", "class_half_edge.html#a8c90288f66768884f42b0588055eb4bf", null ],
    [ "prev", "class_half_edge.html#a02bbf630ad01fd4d7bf4af38e286844e", null ],
    [ "twin", "class_half_edge.html#a37e7696a7131767a0c76e45ed69be4c5", null ]
];