var class_vertex =
[
    [ "Vertex", "class_vertex.html#a20b58fa7832dbe1d4d8ff668dbc4a67e", null ],
    [ "incidentEdge", "class_vertex.html#ad184af21e1f2e7fbd1d49099f3111b34", null ],
    [ "x", "class_vertex.html#af2602132c3297d81bc9f8ee54867445b", null ],
    [ "y", "class_vertex.html#a7563c83da86f4a0831144bc823fec2b0", null ]
];