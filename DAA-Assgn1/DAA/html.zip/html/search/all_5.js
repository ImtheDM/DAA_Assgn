var searchData=
[
  ['halfedge_0',['HalfEdge',['../class_half_edge.html',1,'HalfEdge'],['../class_half_edge.html#adf7f4bd68f46211cf8323f0585ed6242',1,'HalfEdge::HalfEdge(Vertex *v)'],['../class_half_edge.html#a964874103e39fa4bd10b95493d0c35ad',1,'HalfEdge::HalfEdge(Vertex *v, HalfEdge *e)']]]
];
