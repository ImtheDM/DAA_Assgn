var searchData=
[
  ['incidentedge_0',['incidentEdge',['../class_vertex.html#ad184af21e1f2e7fbd1d49099f3111b34',1,'Vertex::incidentEdge()'],['../class_face.html#a6e5f93a441df5d11260fcad7b0ba13bf',1,'Face::incidentEdge()']]],
  ['isnotch_1',['isNotch',['../main_8cpp.html#ad7f41cdef5889c804b645fc0f93fa8b2',1,'main.cpp']]]
];
