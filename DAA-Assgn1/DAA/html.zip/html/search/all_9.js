var searchData=
[
  ['origin_0',['origin',['../class_half_edge.html#a8c90288f66768884f42b0588055eb4bf',1,'HalfEdge']]]
];
