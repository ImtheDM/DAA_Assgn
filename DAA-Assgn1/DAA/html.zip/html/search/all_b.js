var searchData=
[
  ['remove_0',['remove',['../main_8cpp.html#a1c84190b027c2a974c99f9bd4d1c9755',1,'main.cpp']]]
];
