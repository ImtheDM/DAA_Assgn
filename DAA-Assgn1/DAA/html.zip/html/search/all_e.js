var searchData=
[
  ['vertex_0',['Vertex',['../class_vertex.html',1,'Vertex'],['../class_vertex.html#a20b58fa7832dbe1d4d8ff668dbc4a67e',1,'Vertex::Vertex()']]]
];
