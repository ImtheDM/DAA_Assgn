var searchData=
[
  ['isnotch_0',['isNotch',['../main_8cpp.html#ad7f41cdef5889c804b645fc0f93fa8b2',1,'main.cpp']]]
];
